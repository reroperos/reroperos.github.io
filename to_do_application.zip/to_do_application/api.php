<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-Type: application/json");


require_once 'db.php';

$action = $_REQUEST['action'] ?? '';

if ($action == 'create') {
    $task = $_POST['task'] ?? '';
    $desc = $_POST['description'] ?? ''; 
    
    $sql  = "INSERT INTO tasks (task_name, description) VALUES (:task, :desc)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['task' => $task, 'desc' => $desc]);
    
    echo json_encode(["status" => "success", "message" => "Task Added"]);
}

elseif ($action == 'read') {
    $sql  = "SELECT id, task_name, description FROM tasks ORDER BY id DESC";
    $stmt = $pdo->query($sql);
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($tasks);
}

elseif ($action == 'update') {
    $id   = $_POST['id'] ?? null;
    $task = $_POST['task'] ?? '';
    $desc = $_POST['description'] ?? '';
    
    if ($id) {
        $sql  = "UPDATE tasks SET task_name = :task, description = :desc WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['task' => $task, 'desc' => $desc, 'id' => $id]);
        echo json_encode(["status" => "success", "message" => "Task Updated"]);
    } else {
        echo json_encode(["status" => "error", "message" => "ID missing"]);
    }
}

elseif ($action == 'delete') {
    $id   = $_POST['id'] ?? null;
    $sql  = "DELETE FROM tasks WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);
    
    echo json_encode(["status" => "success", "message" => "Task Deleted"]);
}

else {
    echo json_encode(["status" => "error", "message" => "Invalid action: " . $action]);
}
?>