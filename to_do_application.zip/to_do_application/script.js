document.addEventListener("DOMContentLoaded", loadTasks);

// Global variable to track if we are editing
let editMode = false;
let editId = null;

function loadTasks() {
    fetch('api.php?action=read')
        .then(response => response.json())
        .then(data => {
            const list = document.getElementById('taskList');
            list.innerHTML = ""; 

            if (data.length === 0) {
                list.innerHTML = "<li style='text-align:center; color:#888; padding: 20px;'>No tasks yet.</li>";
                return;
            }

            data.forEach(task => {
                createTaskElement(task.id, task.task_name, task.description || "No description provided.");
            });
        })
        .catch(error => {
            console.error("Error:", error);
        });
}

function createTaskElement(id, taskName, taskDesc) {
    const list = document.getElementById('taskList');
    let li = document.createElement('li');
    li.className = 'task-item';
    li.id = 'task-' + id;

    // We use data-attributes to store text safely to avoid quote issues in HTML
    li.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:flex-start; padding: 10px; border-bottom: 1px solid #eee;">
            <div style="max-width: 70%;">
                <strong class="task-title" style="display:block; font-size:16px;">${taskName}</strong>
                <p class="task-desc" style="margin:5px 0 0 0; font-size:13px; color:#666;">${taskDesc}</p>
            </div>
            <div class="task-buttons" style="display:flex; gap: 5px;">
                <button class="btn-edit" onclick="prepareEdit(${id}, this)" style="background:#004a99; color:white; border:none; padding:5px 10px; cursor:pointer; border-radius:4px;">Edit</button>
                <button class="btn-delete" onclick="deleteTask(${id})" style="background:#d9534f; color:white; border:none; padding:5px 10px; cursor:pointer; border-radius:4px;">Delete</button>
            </div>
        </div>
    `;
    list.appendChild(li);
}

// 1. This fills the form with the data to be edited
function prepareEdit(id, button) {
    const li = button.closest('li');
    const currentTitle = li.querySelector('.task-title').innerText;
    const currentDesc = li.querySelector('.task-desc').innerText;

    document.getElementById('taskInput').value = currentTitle;
    document.getElementById('descInput').value = currentDesc;

    // Change button text and state
    const addBtn = document.querySelector('button[onclick="addTask()"]');
    addBtn.innerText = "Update Task";
    addBtn.style.background = "#28a745"; // Green for update
    
    editMode = true;
    editId = id;

    // Scroll to top so user sees the form
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// 2. This handles both Adding and Updating
function addTask() {
    const titleInput = document.getElementById('taskInput');
    const descInput = document.getElementById('descInput'); 
    const addBtn = document.querySelector('button[onclick="addTask()"]');

    if (!titleInput.value.trim()) return alert("Please enter a task title!");

    const formData = new FormData();
    
    if (editMode) {
        formData.append('action', 'update');
        formData.append('id', editId);
    } else {
        formData.append('action', 'create');
    }

    formData.append('task', titleInput.value.trim());
    formData.append('description', descInput.value.trim());

    fetch('api.php', { method: 'POST', body: formData })
        .then(res => res.json())
        .then(data => {
            // Reset form
            titleInput.value = "";
            descInput.value = "";
            editMode = false;
            editId = null;
            addBtn.innerText = "+ Add Task";
            addBtn.style.background = ""; // Reset to original color
            
            loadTasks();
        })
        .catch(err => alert("Error saving task."));
}

function deleteTask(id) {
    if (confirm("Delete this task?")) {
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', id);

        fetch('api.php', { method: 'POST', body: formData })
            .then(() => loadTasks());
    }
}